#pragma once
#include <JuceHeader.h>
#include "PresetConstants.h"

class PresetManager
{
public:
    PresetManager();
    ~PresetManager() = default;

    void saveStore(int index, const juce::ValueTree& currentState);
    juce::ValueTree getStore(int index) const;
    void clearStore(int index);

    void setStoreName(int index, const juce::String& newName);
    juce::String getStoreName(int index) const;

    void setStorePinned(int index, bool shouldPin);
    bool isStorePinned(int index) const;

    juce::Array<int> getPinnedStores() const;

    std::unique_ptr<juce::XmlElement> createXml() const;
    void loadFromXml(juce::XmlElement* xml);

    void saveStoreSet(const juce::String& setName, const juce::Array<int>& pinnedStores);
    void removeStoreSet(const juce::String& setName);
    juce::StringArray getStoreSetNames() const;
    juce::Array<int> getStoresInSet(const juce::String& setName) const;

private:
    juce::String getStoreNodeName(int index) const;
    juce::String getDefaultStoreName(int index) const;
    juce::ValueTree getOrCreateStoreNode(int index);
    juce::ValueTree getOrCreateStoreSetsNode();

    juce::ValueTree storesTree{ PresetTags::StoresTreeType };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PresetManager)
};