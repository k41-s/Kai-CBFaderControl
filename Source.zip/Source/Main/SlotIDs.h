#pragma once
#include <JuceHeader.h>

namespace SlotIdStringPrefixes
{
	// Regular slot parameters
    static const juce::String isActive = "isActive_";
    static const juce::String slotName = "slotName_";
    static const juce::String slotColour = "slotColour_";
    static const juce::String volume = "volume_";
    static const juce::String mute = "mute_";
    static const juce::String pan = "pan_";
    static const juce::String solo = "solo_";
    static const juce::String soloSafe = "soloSafe_";
    static const juce::String sipMuted = "sipMuted_";

	// Stereo linking parameters
    static const juce::String isStereo = "isStereo";
    static const juce::String isStereoLinked = isStereo + "Linked_";
    static const juce::String isStereoMain = isStereo + "Main_";
    static const juce::String linkedSlotId = "linkedSlotId_";
    static const juce::String xpStereo = "xpStereo_";

	// Grouping parameters
    static const juce::String group = "group";
    static const juce::String groupId = group + "Id_";
    static const juce::String groupRole = group + "Role_";
    static const juce::String groupColour = group + "Colour_";

	// VCA parameters
    static const juce::String vca = "vca";
    static const juce::String vcaEnabled = vca + "Enabled_";
    static const juce::String vcaVolume = vca + "Volume_";
    static const juce::String vcaMute = vca + "Mute_";
    static const juce::String vcaName = vca + "Name_";
    static const juce::String isVcaExpanded = vca + "Expanded_";

    // Presets
    static const juce::String slotOrder = "slotOrder_";

    // Link Mask
	static const juce::String linkPolarityInverse = "linkPolarityInverse_";
	static const juce::String linkMaskVolume = "linkMaskVolume_";
	static const juce::String linkMaskMute = "linkMaskMute_";
	static const juce::String linkMaskSolo = "linkMaskSolo_";
	static const juce::String linkMaskPan = "linkMaskPan_";

    static const juce::String customLinkedId = "customLinkedId_";
    static const juce::String customLinkedIsVca = "customLinkedIsVca_";
    static const juce::String linkColourIndex = "linkColourIndex_";
}

struct SlotIDs
{
    static juce::String isActive(int i) { return SlotIdStringPrefixes::isActive + juce::String(i); }
    static juce::String slotName(int i) { return SlotIdStringPrefixes::slotName + juce::String(i); }
    static juce::String slotColour(int i) { return SlotIdStringPrefixes::slotColour + juce::String(i); }
    static juce::String volume(int i) { return SlotIdStringPrefixes::volume + juce::String(i); }
    static juce::String mute(int i) { return SlotIdStringPrefixes::mute + juce::String(i); }
    static juce::String pan(int i) { return SlotIdStringPrefixes::pan + juce::String(i); }
    static juce::String solo(int i) { return SlotIdStringPrefixes::solo + juce::String(i); }
    static juce::String soloSafe(int i) { return SlotIdStringPrefixes::soloSafe + juce::String(i); }
    static juce::String sipMuted(int i) { return SlotIdStringPrefixes::sipMuted + juce::String(i); }

    static juce::String isStereoLinked(int i) { return SlotIdStringPrefixes::isStereoLinked + juce::String(i); }
    static juce::String isStereoMain(int i) { return SlotIdStringPrefixes::isStereoMain + juce::String(i); }
    static juce::String linkedSlotId(int i) { return SlotIdStringPrefixes::linkedSlotId + juce::String(i); }
    static juce::String xpStereo(int i) { return SlotIdStringPrefixes::xpStereo + juce::String(i); }
    
    static juce::String groupId(int i) { return SlotIdStringPrefixes::groupId + juce::String(i); }
    static juce::String groupRole(int i) { return SlotIdStringPrefixes::groupRole + juce::String(i); }
    static juce::String groupColour(int i) { return SlotIdStringPrefixes::groupColour + juce::String(i); }

    static juce::String vcaEnabled(int grp) { return SlotIdStringPrefixes::vcaEnabled + juce::String(grp); }
    static juce::String vcaVolume(int vca) { return SlotIdStringPrefixes::vcaVolume + juce::String(vca); }
    static juce::String vcaMute(int vca) { return SlotIdStringPrefixes::vcaMute + juce::String(vca); }
    static juce::String vcaName(int vca) { return SlotIdStringPrefixes::vcaName + juce::String(vca); }
    static juce::String isVcaExpanded(int vca) { return SlotIdStringPrefixes::isVcaExpanded + juce::String(vca); }

    static juce::Identifier visualSlotOrder() { return SlotIdStringPrefixes::slotOrder + "array"; }

    static juce::Identifier targetIP() { return "targetIP"; }
    static juce::Identifier incomingPort() { return "incomingPort"; }
    static juce::Identifier outgoingPort() { return "outgoingPort"; }
    static juce::Identifier isConnected() { return "isConnected"; }

    static inline juce::String linkPolarityInverse(int slotIdx) { return SlotIdStringPrefixes::linkPolarityInverse + juce::String(slotIdx); }
    static inline juce::String linkMaskVolume(int slotIdx) { return SlotIdStringPrefixes::linkMaskVolume + juce::String(slotIdx); }
    static inline juce::String linkMaskMute(int slotIdx) { return SlotIdStringPrefixes::linkMaskMute + juce::String(slotIdx); }
    static inline juce::String linkMaskSolo(int slotIdx) { return SlotIdStringPrefixes::linkMaskSolo + juce::String(slotIdx); }
    static inline juce::String linkMaskPan(int slotIdx) { return SlotIdStringPrefixes::linkMaskPan + juce::String(slotIdx); }
    
    static juce::String customLinkedId(int i) { return SlotIdStringPrefixes::customLinkedId + juce::String(i); }
    static juce::String customLinkedIsVca(int i) { return SlotIdStringPrefixes::customLinkedIsVca + juce::String(i); }
    static inline juce::String linkColourIndex(int slotIdx) { return SlotIdStringPrefixes::linkColourIndex + juce::String(slotIdx); }
};

namespace ParamSlotNameStringPrefixes
{
	static const juce::String isActive = "Is Active ";
    static const juce::String volume = "Volume ";
    static const juce::String mute = "Mute ";
    static const juce::String pan = "Pan ";
    static const juce::String solo = "Solo ";
    static const juce::String soloSafe = "Solo Safe ";

	static const juce::String vcaEnabled = "VCA Enabled ";
    static const juce::String vcaVolume = "VCA Volume ";
    static const juce::String vcaMute = "VCA Mute ";
    static const juce::String isVcaExpanded = "VCA Expanded ";
}

struct ParamSlotNames
{
    static juce::String isActive(int i) { return ParamSlotNameStringPrefixes::isActive + juce::String(i); }
    static juce::String volume(int i) { return ParamSlotNameStringPrefixes::volume + juce::String(i); }
    static juce::String mute(int i) { return ParamSlotNameStringPrefixes::mute + juce::String(i); }
    static juce::String pan(int i) { return ParamSlotNameStringPrefixes::pan + juce::String(i); }
    static juce::String solo(int i) { return ParamSlotNameStringPrefixes::solo + juce::String(i); }
    static juce::String soloSafe(int i) { return ParamSlotNameStringPrefixes::soloSafe + juce::String(i); }

    static juce::String vcaEnabled(int i) { return ParamSlotNameStringPrefixes::vcaEnabled + juce::String(i); }
    static juce::String vcaVolume(int i) { return ParamSlotNameStringPrefixes::vcaVolume + juce::String(i); }
    static juce::String vcaMute(int i) { return ParamSlotNameStringPrefixes::vcaMute + juce::String(i); }
    static juce::String isVcaExpanded(int i) { return ParamSlotNameStringPrefixes::isVcaExpanded + juce::String(i); }
};