#include "PerformanceView.h"
#include "../../../Main/SlotIDs.h"
#include "../../../Main/PresetManager/PresetConstants.h"
#include "../../Components/UIConstants.h"
#include "../../CustomLookAndFeel/MyColours.h"
#include "../../../Utils/Enums/ContextMenuId.h"
#include "../../../Utils/Enums/StoresMenuIds.h"
#include "../../../Utils/Enums/DialogConstants.h"
#include "../../../Utils/StateUtils/SlotStateHelpers.h"
#include "../../Components/PinnedStoreButton/PinnedStoreButton.h"
#include "../../../Utils/ScopedAtomicSetter.h"

PerformanceView::PerformanceView(KaiCBFaderControlAudioProcessor& p)
	:processor(p)
{
	init();
}

void PerformanceView::init()
{
	setWantsKeyboardFocus(true);
	setLookAndFeel(&performanceLF);
	selectedItems.addChangeListener(this);
	processor.globalSlotRegistry->addChangeListener(this);
	configComponents();
	registerListeners();
	addAndMakeVisible(lasso);
	syncSlotOrderFromState();
	triggerSettling();
}

void PerformanceView::configComponents()
{
	createFaderSlots();
	createVcaFaderSlots();
	configSetupButton();
	configEditLayoutButton();
	configPresetsButton();
	configStoresButton();
	configActiveStoreLabel();
	configImages();
}

void PerformanceView::createFaderSlots()
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		auto* slot = slots.add(new PerformanceSlotItem(processor, i));
		bindSelectionEvents(slot);
		slot->onBulkToggleRequest = [this](bool isMute, bool newState, PerformanceSlotItem* s) { 
			handleBulkToggle(isMute, newState, s);
		};
		addAndMakeVisible(slot);
	}
}

void PerformanceView::createVcaFaderSlots()
{
	for (int i = 1; i <= PluginConstants::numVcas; ++i)
	{
		auto* vca = vcaSlots.add(new VcaSlotItem(processor, i));
		bindSelectionEvents(vca);
		addAndMakeVisible(vca);
	}
}

void PerformanceView::configSetupButton()
{
	addAndMakeVisible(setupButton);
	setupButton.onClick = [this]()
		{
			if (onNavigateToSetup)
				onNavigateToSetup();
		};
}

void PerformanceView::configEditLayoutButton()
{
	editLayoutButton.setButtonText("< Locked >");
	editLayoutButton.setClickingTogglesState(true);
	editLayoutButton.setToggleState(false, juce::dontSendNotification);
	addAndMakeVisible(editLayoutButton);

	editLayoutButton.onClick = [this]()
		{
			bool isEditing = editLayoutButton.getToggleState();
			editLayoutButton.setButtonText(isEditing ? "< Unlocked >" : "< Locked >");
			
			for (auto* slot : slots)
				slot->setEditMode(isEditing);

			for (auto* vca : vcaSlots)
				vca->setEditMode(isEditing);
		};
}

void PerformanceView::configPresetsButton()
{
	presetsButton.setButtonText(PresetTags::PresetsButtonText);
	addAndMakeVisible(presetsButton);

	presetsButton.onClick = [this]() { showPresetsMenu(); };
}

void PerformanceView::showPresetsMenu()
{
	juce::PopupMenu menu;
	menu.addItem(PresetsMenuIds::LoadPreset, "Load Preset...");
	menu.addItem(PresetsMenuIds::SavePreset, "Save Preset As...");

	menu.showMenuAsync(juce::PopupMenu::Options()
		.withTargetComponent(presetsButton)
		.withParentComponent(this),
		[this](int result)
		{
			if (result == PresetsMenuIds::LoadPreset) 
				handleLoadPresetRequest();
			else if (result == PresetsMenuIds::SavePreset) 
				handleSavePresetRequest();
		});
}

void PerformanceView::handleSavePresetRequest()
{
	fileChooser = std::make_unique<juce::FileChooser>("Save Preset",
		juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),
		"*.xml");

	auto chooserFlags = juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles;
	fileChooser->launchAsync(chooserFlags, [this](const juce::FileChooser& fc)
		{
			auto file = fc.getResult();
			if (file != juce::File{})
			{
				processor.savePresetToFile(file);
				hasUnsavedChanges = false;
				triggerAsyncUpdate();
			}
		});
}

void PerformanceView::handleLoadPresetRequest()
{
	if (hasUnsavedChanges)
	{
		showUnsavedChangesWarningAsync( [this]() { launchLoadPresetChooser(); });
	}
	else
	{
		launchLoadPresetChooser();
	}
}

void PerformanceView::launchLoadPresetChooser()
{
	fileChooser = std::make_unique<juce::FileChooser>("Load Preset",
		juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),
		"*.xml");

	auto chooserFlags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;
	fileChooser->launchAsync(chooserFlags, [this](const juce::FileChooser& fc)
		{
			auto file = fc.getResult();
			if (file != juce::File{})
			{
				auto xmlRoot = processor.loadPresetFile(file);
				if (xmlRoot != nullptr)
				{
					showPresetLoadDialog(std::move(xmlRoot));
				}
			}
		});
}

void PerformanceView::showPresetLoadDialog(std::unique_ptr<juce::XmlElement> xmlRoot)
{
	presetToLoadXml = std::move(xmlRoot);

	auto* dialog = new PresetLoadDialog(
		[this](const RecallScope& scope) {
			if (presetToLoadXml != nullptr)
			{
				PresetHelpers::selectivelyApplyState(processor.apvts, *processor.presetManager, *presetToLoadXml, scope);

				hasUnsavedChanges = false;
				triggerSettling();

				updatePinnedButtons();

				int currentStore = SlotStateHelpers::getActiveStoreId(processor.apvts);
				updateActiveStoreLabel(currentStore);

				presetToLoadXml.reset();
			}
			if (presetDialogWindow != nullptr)
				presetDialogWindow->exitModalState(DialogActions::Confirm);
		},
		[this]() {
			presetToLoadXml.reset();
			if (presetDialogWindow != nullptr) 
				presetDialogWindow->exitModalState(DialogActions::Cancel);
		}
	);

	dialog->setLookAndFeel(&performanceLF);
	dialog->setSize(450, 500);

	juce::DialogWindow::LaunchOptions options;
	options.content.setOwned(dialog);
	options.dialogTitle = "Selective Preset Recall";
	options.dialogBackgroundColour = MyColours::background;
	options.escapeKeyTriggersCloseButton = true;
	options.useNativeTitleBar = false;
	options.resizable = false;

	presetDialogWindow = options.launchAsync();
}

void PerformanceView::configStoresButton()
{
	storesButton.setButtonText(PresetTags::StoresButtonText);
	addAndMakeVisible(storesButton);
	storesButton.onClick = [this]() { showStoresMenu(); };
}

void PerformanceView::configActiveStoreLabel()
{
	addAndMakeVisible(activeStoreLabel);
	activeStoreLabel.setJustificationType(juce::Justification::centred);
	activeStoreLabel.setFont(juce::Font(15.0f, juce::Font::bold));
	activeStoreLabel.setColour(juce::Label::textColourId, juce::Colours::white);

	int index = SlotStateHelpers::getActiveStoreId(processor.apvts);
	updateActiveStoreLabel(index);
}

void PerformanceView::updateActiveStoreLabel(int index)
{
	if (index == PresetConstants::noStore)
	{
		activeStoreLabel.setText("Unsaved", juce::dontSendNotification);
	}
	else
	{
		juce::String name = processor.presetManager->getStoreName(index);
		activeStoreLabel.setText(name, juce::dontSendNotification);
	}
}

void PerformanceView::showStoresMenu()
{
	juce::PopupMenu menu;

	menu.addItem(SavePinnedAsSet, "Save Current Pinned as Set...");

	juce::StringArray setNames = processor.presetManager->getStoreSetNames();
	if (!setNames.isEmpty())
	{
		addSetsSubMenu(setNames, menu);
	}
	menu.addSeparator();

	for (int i = 1; i <= PresetConstants::numStores; ++i)
	{
		addStoreSubMenu(i, menu);
	}

	menu.showMenuAsync(juce::PopupMenu::Options()
		.withTargetComponent(storesButton)
		.withParentComponent(this)
		.withMaximumNumColumns(1),
		[this](int result) { handleStoresMenuResult(result); });
}

void PerformanceView::addSetsSubMenu(juce::StringArray& setNames, juce::PopupMenu& menu)
{
	juce::PopupMenu setsMenu;
	for (int i = 0; i < setNames.size(); ++i)
	{
		juce::PopupMenu singleSetMenu;
		singleSetMenu.addItem(RecallSetBase + i, "Recall (Pin these stores)");
		singleSetMenu.addItem(BaseHideSet + i, "Hide Set");
		singleSetMenu.addItem(RemoveSetBase + i, "Remove Set");
		setsMenu.addSubMenu(setNames[i], singleSetMenu);
	}
	menu.addSubMenu("Store Sets", setsMenu);
}

void PerformanceView::addStoreSubMenu(int i, juce::PopupMenu& menu)
{
	juce::PopupMenu storeSubMenu;
	populateStoreMenuOptions(i, storeSubMenu);

	juce::String name = processor.presetManager->getStoreName(i);
	menu.addSubMenu(name, storeSubMenu);
}

void PerformanceView::populateStoreMenuOptions(int i, juce::PopupMenu& storeMenu)
{
	storeMenu.addItem(BaseRecall + i, "Recall");
	storeMenu.addItem(BaseSave + i, "Save (Overwrite)");
	storeMenu.addItem(BaseRename + i, "Rename...");
	storeMenu.addSeparator();
	storeMenu.addItem(BaseClear + i, "Clear State");

	bool isPinned = processor.presetManager->isStorePinned(i);
	storeMenu.addItem(BasePin + i, isPinned ? "Unpin from Footer" : "Pin to Footer");
}

void PerformanceView::showPinnedStoreMenu(int i, juce::Button* btn)
{
	juce::PopupMenu menu;

	populateStoreMenuOptions(i, menu);

	menu.showMenuAsync(juce::PopupMenu::Options()
		.withTargetComponent(btn)
		.withParentComponent(this)
		.withMaximumNumColumns(1),
		[this](int result) { handleStoresMenuResult(result); });
}

void PerformanceView::handleStoresMenuResult(int result)
{
	if (result == 0) return;

	if (result >= BaseHideSet) 
	{
		handleHideSetMenuResult(result - BaseHideSet);
	}
	else if (result >= RemoveSetBase)
	{
		handleRemoveSetMenuResult(result);
	}
	else if (result >= RecallSetBase)
	{
		handleRecallSetMenuResult(result);
	}
	else if (result == SavePinnedAsSet)
	{
		promptForStoreSetName();
	}
	else if (result > BaseClear)
	{
		int storeIdx = result - StoresMenuIds::BaseClear;
		processor.presetManager->clearStore(storeIdx);

		updatePinnedButtons();
	}
	else if (result > BaseRename)
	{
		int index = result - BaseRename;
		promptForStoreName(index);
	}
	else if (result > BasePin)
	{
		int index = result - BasePin;
		bool isPinned = processor.presetManager->isStorePinned(index);
		processor.presetManager->setStorePinned(index, !isPinned);
		triggerAsyncUpdate();
	}
	else if (result > BaseSave)
	{
		handleStoreSaveMenuResult(result);
	}
	else if (result > BaseRecall)
	{
		handleStoreRecallMenuResult(result);
	}
}

void PerformanceView::promptForStoreSetName()
{
	auto* alert = new juce::AlertWindow("Save Store Set", "Enter a name for this set:", juce::AlertWindow::NoIcon);
	alert->addTextEditor(AlertFieldIDs::setName, "", "Set Name");
	alert->addButton(DialogStrings::SaveBtn, DialogActions::Confirm, juce::KeyPress(juce::KeyPress::returnKey));
	alert->addButton(DialogStrings::CancelBtn, DialogActions::Cancel, juce::KeyPress(juce::KeyPress::escapeKey));
	alert->setLookAndFeel(&performanceLF);

	alert->enterModalState(true, juce::ModalCallbackFunction::create([this, alert](int choice) {
		if (choice == DialogActions::Confirm)
		{
			juce::String newName = alert->getTextEditorContents(AlertFieldIDs::setName);
			if (newName.isNotEmpty())
			{
				auto pinned = processor.presetManager->getPinnedStores();
				processor.presetManager->saveStoreSet(newName, pinned);
			}
		}
		}), true);
}

void PerformanceView::handleRecallSetMenuResult(int result)
{
	int index = result - RecallSetBase;
	juce::StringArray setNames = processor.presetManager->getStoreSetNames();

	if (juce::isPositiveAndBelow(index, setNames.size()))
	{
		wipeCurrentPins();
		pinStoresFromSet(setNames, index);
		triggerAsyncUpdate();
	}
}

void PerformanceView::wipeCurrentPins()
{
	for (int i = 1; i <= PresetConstants::numStores; ++i)
	{
		if (processor.presetManager->isStorePinned(i))
			processor.presetManager->setStorePinned(i, false);
	}
}

void PerformanceView::pinStoresFromSet(juce::StringArray& setNames, int index)
{
	juce::Array<int> storesToPin = processor.presetManager->getStoresInSet(setNames[index]);
	for (int storeId : storesToPin)
	{
		processor.presetManager->setStorePinned(storeId, true);
	}
}

void PerformanceView::handleRemoveSetMenuResult(int result)
{
	int index = result - RemoveSetBase;
	juce::StringArray setNames = processor.presetManager->getStoreSetNames();

	if (juce::isPositiveAndBelow(index, setNames.size()))
	{
		processor.presetManager->removeStoreSet(setNames[index]);
	}
}

void PerformanceView::handleHideSetMenuResult(int setIndex)
{
	auto setNames = processor.presetManager->getStoreSetNames();
	if (setIndex >= 0 && setIndex < setNames.size())
	{
		juce::String setName = setNames[setIndex];
		auto storesToHide = processor.presetManager->getStoresInSet(setName);

		for (int storeId : storesToHide)
		{
			processor.presetManager->setStorePinned(storeId, false);
		}

		updatePinnedButtons();
		triggerAsyncUpdate();
	}
}

void PerformanceView::promptForStoreName(int index)
{
	auto* alert = new juce::AlertWindow("Rename Store", "Enter a new name:", juce::AlertWindow::NoIcon);
	
	alert->setLookAndFeel(&performanceLF);
	alert->addTextEditor(AlertFieldIDs::storeName, processor.presetManager->getStoreName(index), "Name");

	if (auto* editor = alert->getTextEditor(AlertFieldIDs::storeName))
		editor->setInputRestrictions(PresetConstants::maxStoreNameLength);

	alert->addButton(DialogStrings::SaveBtn, DialogActions::Confirm, juce::KeyPress(juce::KeyPress::returnKey));
	alert->addButton(DialogStrings::CancelBtn, DialogActions::Cancel, juce::KeyPress(juce::KeyPress::escapeKey));

	alert->enterModalState(true, juce::ModalCallbackFunction::create([this, alert, index](int result)
		{
			if (result == DialogActions::Confirm)
			{
				handleStoreRename(alert, index);
			}
		}), true);
}

void PerformanceView::handleStoreRename(juce::AlertWindow* alert, int index)
{
	juce::String newName = alert->getTextEditorContents("nameField");
	if (newName.isNotEmpty())
	{
		processor.presetManager->setStoreName(index, newName);
		triggerAsyncUpdate();

		if (SlotStateHelpers::getActiveStoreId(processor.apvts) == index)
		{
			updateActiveStoreLabel(index);
		}
	}
	processor.presetManager->saveStore(index, processor.apvts.copyState());
}

void PerformanceView::handleStoreSaveMenuResult(int result)
{
	int index = result - BaseSave;

	processor.isRestoringState = true;
	SlotStateHelpers::setActiveStoreId(processor.apvts, index);
	processor.isRestoringState = false;

	processor.presetManager->saveStore(index, processor.apvts.copyState());

	hasUnsavedChanges = false;
	triggerSettling();
	updateActiveStoreLabel(index);
}

void PerformanceView::handleStoreRecallMenuResult(int result)
{
	int index = result - BaseRecall;
	requestStoreRecall(index);
}

void PerformanceView::requestStoreRecall(int storeIdx)
{
	auto executeRecall = [this, storeIdx]() {
		int currentIndex = SlotStateHelpers::getActiveStoreId(processor.apvts);
		if (currentIndex == storeIdx)
			processor.forceRecallStore(storeIdx);
		else
			SlotStateHelpers::setActiveStoreId(processor.apvts, storeIdx);
		};

	if (hasUnsavedChanges) {
		showUnsavedChangesWarningAsync(executeRecall);
	}
	else {
		executeRecall();
	}
}

void PerformanceView::showUnsavedChangesWarningAsync(std::function<void()> onConfirm)
{
	juce::AlertWindow::showAsync(juce::MessageBoxOptions()
		.withParentComponent(this)
		.withIconType(juce::MessageBoxIconType::WarningIcon)
		.withTitle(DialogStrings::UnsavedTitle)
		.withMessage("You have unsaved changes that will be discarded. Continue?")
		.withButton("Yes, discard")
		.withButton("No, cancel"),
		[onConfirm](int choice) {
			if (choice == DialogActions::Confirm) {
				onConfirm();
			}
		});
}

void PerformanceView::configImages()
{
	addAndMakeVisible(cbLogo);
	addAndMakeVisible(xPatchImg);
}

void PerformanceView::registerListeners()
{
	addRegularSlotListeners();
	addVcaListeners();
	processor.apvts.state.addListener(this);
	processor.apvts.addParameterListener(PresetTags::ActiveStoreParamId, this);
}

void PerformanceView::addRegularSlotListeners()
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		processor.apvts.addParameterListener(SlotIDs::isActive(i), this);
	}
}

void PerformanceView::addVcaListeners()
{
	for (int i = 1; i <= PluginConstants::numVcas; ++i)
	{
		processor.apvts.addParameterListener(SlotIDs::isVcaExpanded(i), this);
		processor.apvts.addParameterListener(SlotIDs::vcaEnabled(i), this);
	}
}

PerformanceView::~PerformanceView()
{
	deregisterListeners();
	selectedItems.removeChangeListener(this);
	setLookAndFeel(nullptr);
}

void PerformanceView::deregisterListeners()
{
	removeRegularSlotListeners();
	removeVcaListeners();
	processor.apvts.state.removeListener(this);
	processor.globalSlotRegistry->removeChangeListener(this);
	processor.apvts.removeParameterListener(PresetTags::ActiveStoreParamId, this);
}

void PerformanceView::removeRegularSlotListeners()
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		processor.apvts.removeParameterListener(SlotIDs::isActive(i), this);
	}
}

void PerformanceView::removeVcaListeners()
{
	for (int i = 1; i <= PluginConstants::numVcas; ++i)
	{
		processor.apvts.removeParameterListener(SlotIDs::isVcaExpanded(i), this);
		processor.apvts.removeParameterListener(SlotIDs::vcaEnabled(i), this);
	}
}

void PerformanceView::parameterChanged(const juce::String& parameterID, float newValue)
{
	if (parameterID == PresetTags::ActiveStoreParamId)
	{
		handleActiveStoreParamChanged();
	}
	else
	{
		for (int i = 1; i <= PluginConstants::numVcas; ++i)
		{
			if (parameterID == SlotIDs::isVcaExpanded(i))
			{
				if (newValue > 0.5f)
				{
					juce::MessageManager::callAsync([this, i]() 
						{
							reactivateGroupMembers(i);
						});
				}
				break;
			}
		}

		if (!processor.isRestoringState && !isSettling && !hasUnsavedChanges)
		{
			hasUnsavedChanges = true;
		}
	}
	triggerAsyncUpdate();
}

void PerformanceView::handleActiveStoreParamChanged()
{
	juce::MessageManager::callAsync([this]() 
	{
		int index = SlotStateHelpers::getActiveStoreId(processor.apvts);
		updateActiveStoreLabel(index);
	});
}

void PerformanceView::valueTreePropertyChanged(juce::ValueTree& tree, const juce::Identifier& property)
{
	if (property.toString() != PresetTags::ActiveStoreParamId &&
		!processor.isRestoringState && 
		!isSettling && !hasUnsavedChanges)
	{
		hasUnsavedChanges = true;
		triggerAsyncUpdate();
	}

	if (SlotStateHelpers::isStereoOrGroupProperty(property.toString()))
	{
		triggerAsyncUpdate();
	}

	if (property == SlotIDs::visualSlotOrder())
	{
		syncSlotOrderFromState();
		triggerAsyncUpdate();
	}
}

void PerformanceView::valueTreeRedirected(juce::ValueTree& treeWhichHasBeenChanged)
{
	hasUnsavedChanges = false;
	syncSlotOrderFromState();
	triggerSettling();
	handleActiveStoreParamChanged();
}

void PerformanceView::handleAsyncUpdate()
{
	juce::String oldSig = lastLayoutSignature;

	resized();
	repaint();

	if (oldSig != lastLayoutSignature && onLayoutChangeRequest)
		onLayoutChangeRequest();
}

void PerformanceView::changeListenerCallback(juce::ChangeBroadcaster* source)
{
	if (source == &selectedItems)
	{
		for (auto* slot : slots)
			slot->setSelected(selectedItems.isSelected(slot->getSelectionId()));

		for (auto* vca : vcaSlots)
			vca->setSelected(selectedItems.isSelected(vca->getSelectionId()));
	}
	else if (source == &processor.globalSlotRegistry.get())
		triggerAsyncUpdate();
}

void PerformanceView::findLassoItemsInArea(juce::Array<int>& itemsFound, const juce::Rectangle<int>& area)
{
	for (auto* slot : slots)
	{
		if (slot->isVisible() && slot->getBounds().intersects(area))
			itemsFound.add(slot->getSelectionId());
	}

	for (auto* vca : vcaSlots)
	{
		if (vca->isVisible() && vca->getBounds().intersects(area))
			itemsFound.add(vca->getSelectionId());
	}
}

juce::SelectedItemSet<int>& PerformanceView::getLassoSelection()
{
	return selectedItems;
}

void PerformanceView::mouseDown(const juce::MouseEvent& e)
{
	grabKeyboardFocus();

	if (handleIsPopupMenuEvent(e)) return;

	if (!e.mods.isShiftDown() && !e.mods.isCommandDown() && !e.mods.isCtrlDown())
		selectedItems.deselectAll();

	lasso.beginLasso(e, this);
}

bool PerformanceView::handleIsPopupMenuEvent(const juce::MouseEvent& e)
{
	if (e.mods.isPopupMenu())
	{
		if (selectedItems.getNumSelected() > 0)
			showContextMenu();

		return true;
	}
	return false;
}

void PerformanceView::mouseDrag(const juce::MouseEvent& e)
{
	lasso.dragLasso(e);
}

void PerformanceView::mouseUp(const juce::MouseEvent& e)
{
	lasso.endLasso();
}

void PerformanceView::timerCallback()
{
	stopTimer();
	isSettling = false;
}

void PerformanceView::handleSlotMouseDown(const juce::MouseEvent& e, BaseSlotItem* slot)
{
	grabKeyboardFocus();

	if (e.mods.isPopupMenu())
	{
		if (!selectedItems.isSelected(slot->getSelectionId()))
		{
			selectedItems.deselectAll();
			selectedItems.addToSelection(slot->getSelectionId());
		}
		showContextMenu();
		return;
	}

	if (e.mods.isCommandDown() || e.mods.isCtrlDown() || e.mods.isShiftDown())
	{
		if (selectedItems.isSelected(slot->getSelectionId()))
			selectedItems.deselect(slot->getSelectionId());
		else
			selectedItems.addToSelection(slot->getSelectionId());
	}
	else
	{
		selectedItems.deselectAll();
		selectedItems.addToSelection(slot->getSelectionId());
	}

	lasso.beginLasso(e.getEventRelativeTo(this), this);
}

void PerformanceView::handleSlotMouseDrag(const juce::MouseEvent& e, BaseSlotItem* slot)
{
	lasso.dragLasso(e.getEventRelativeTo(this));
}

void PerformanceView::handleSlotMouseUp(const juce::MouseEvent& e, BaseSlotItem* slot)
{
	lasso.endLasso();
}

void PerformanceView::bindSelectionEvents(BaseSlotItem* slot)
{
	slot->onBackgroundMouseDown = [this](const juce::MouseEvent& e, BaseSlotItem* s) { handleSlotMouseDown(e, s); };
	slot->onBackgroundMouseDrag = [this](const juce::MouseEvent& e, BaseSlotItem* s) { handleSlotMouseDrag(e, s); };
	slot->onBackgroundMouseUp = [this](const juce::MouseEvent& e, BaseSlotItem* s) { handleSlotMouseUp(e, s); };
}

void PerformanceView::handleBulkToggle(bool isMute, bool newState, PerformanceSlotItem* slotClicked)
{
	auto selectedArrCopy = selectedItems.getItemArray();
	if (selectedArrCopy.isEmpty()) 
		return;

	for (int slotId : selectedArrCopy)
	{
		if (slotId == slotClicked->getIndex())
			continue;

		if (isSlotFullAccess(slotId))
		{
			juce::String paramId = isMute ? SlotIDs::mute(slotId) : SlotIDs::solo(slotId);
			float targetVal = newState ? 1.0f : 0.0f;

			SlotStateHelpers::setParamNormalizedIfChanged(processor.apvts, paramId, targetVal);

			if (!isMute && newState)
			{
				SlotStateHelpers::setSlotMuted(processor.apvts, slotId, false);
			}
		}
	}
}

void PerformanceView::showContextMenu()
{
	juce::PopupMenu menu;
	auto& selectedArr = selectedItems.getItemArray();

	addMenuItems(selectedArr, menu);
	showPopupMenuIfNotEmpty(menu, selectedArr);
}

void PerformanceView::addMenuItems(const juce::Array<int>& selectedArr, juce::PopupMenu& menu)
{
	juce::Array<int> activeSlots;
	juce::Array<int> readOnlySlots;

	sortSelectedSlots(selectedArr, activeSlots, readOnlySlots);

	if (!readOnlySlots.isEmpty())
		addClaimSlotMenuItem(readOnlySlots, menu);

	if (!activeSlots.isEmpty())
		addStandardMenuOptions(readOnlySlots, menu, activeSlots);
}

void PerformanceView::sortSelectedSlots(const juce::Array<int>& selectedArr, juce::Array<int>& activeSlots, juce::Array<int>& readOnlySlots)
{
	for (int idx : selectedArr)
	{
		if (idx > PluginConstants::vcaSelectionOffset || isSlotFullAccess(idx))
			activeSlots.add(idx);
		else
			readOnlySlots.add(idx);
	}
}

bool PerformanceView::isSelectionUnifiedGroup(const juce::Array<int>& normalSlots, const juce::Array<int>& vcaSlots, int& commonGrpId) const
{
	if (vcaSlots.size() > 1) return false;

	commonGrpId = 0;
	if (vcaSlots.size() == 1)
		commonGrpId = vcaSlots[0];

	for (int slotId : normalSlots)
	{
		int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotId);

		if (!SlotStateHelpers::isValidGroup(grpId)) 
			return false;

		if (commonGrpId == 0)
			commonGrpId = grpId;
		else if (commonGrpId != grpId)
			return false;
	}

	return SlotStateHelpers::isValidGroup(commonGrpId);
}

void PerformanceView::addClaimSlotMenuItem(juce::Array<int>& readOnlySlots, juce::PopupMenu& menu)
{
	juce::String text = readOnlySlots.size() == 1
		? "Claim Slot " + juce::String(readOnlySlots[0])
		: "Claim Selected Slots";

	menu.addItem(ClaimSlot, text);
}

void PerformanceView::addStandardMenuOptions(juce::Array<int>& readOnlySlots, juce::PopupMenu& menu, juce::Array<int>& activeSlots)
{
	if (!readOnlySlots.isEmpty())
		menu.addSeparator();

	juce::Array<int> normalSlots;
	juce::Array<int> vcaSlots;
	parseSelectedArray(activeSlots, vcaSlots, normalSlots);

	int commonGrpId = 0;
	bool isUnifiedGroup = isSelectionUnifiedGroup(normalSlots, vcaSlots, commonGrpId);

	if (!normalSlots.isEmpty())
	{
		addNormalSlotItems(normalSlots, menu, !vcaSlots.isEmpty());
	}

	if (isUnifiedGroup && SlotStateHelpers::isValidGroup(commonGrpId))
	{
		addVcaMenuItem(menu, commonGrpId);
		setupAndAddGrpColourMenu(menu, commonGrpId);
		menu.addItem(ContextMenuID::CollectGroupSlots, "Collect Group Slots");
	}

	addLinkMasksMenuItems(activeSlots, menu);
}

void PerformanceView::parseSelectedArray(juce::Array<int>& activeSlots, juce::Array<int>& vcaSlots, juce::Array<int>& normalSlots)
{
	for (int id : activeSlots)
	{
		if (id > PluginConstants::vcaSelectionOffset)
			vcaSlots.add(id - PluginConstants::vcaSelectionOffset);
		else
			normalSlots.add(id);
	}
}

void PerformanceView::addNormalSlotItems(juce::Array<int>& normalSlots, juce::PopupMenu& menu, bool containsVca)
{
	addStereoMenuItems(normalSlots, menu);

	if (!containsVca)
	{
		addGroupMenu(normalSlots, menu);

		if (normalSlots.size() == 1)
			addSingleSlotGroupOptions(normalSlots, menu);
	}

	addSoloSafeMenuItem(normalSlots, menu);
}

void PerformanceView::addLinkMasksMenuItems(juce::Array<int>& activeSlots, juce::PopupMenu& menu)
{
	if (activeSlots.isEmpty()) return;

	if (activeSlots.size() == 2)
	{
		int slotA = activeSlots[0];
		int slotB = activeSlots[1];

		if (getLinkedSelectionId(slotA) == slotB)
		{
			addExistingLinkMenuOptions(activeSlots, menu);
		}
		else if (canCreateCustomLink(slotA, slotB))
		{
			menu.addSeparator();
			menu.addItem(CreateCustomLink, "Link Faders");
		}
	}
	else if (activeSlots.size() == 1)
	{
		if (getLinkedSelectionId(activeSlots[0]) != 0)
		{
			addExistingLinkMenuOptions(activeSlots, menu);
		}
	}
}

bool PerformanceView::canCreateCustomLink(int slotA, int slotB) const
{
	bool isAVca = isVcaSelection(slotA);
	bool isBVca = isVcaSelection(slotB);

	if (isAVca != isBVca)
	{
		int normalId = isAVca ? slotB : slotA;
		int vcaId = isAVca ? getTrueId(slotA) : getTrueId(slotB);

		if (SlotStateHelpers::getGroupId(processor.apvts.state, normalId) == vcaId)
			return false;
	}
	else if (!isAVca && !isBVca)
	{
		int groupA = SlotStateHelpers::getGroupId(processor.apvts.state, slotA);
		int groupB = SlotStateHelpers::getGroupId(processor.apvts.state, slotB);
		if (SlotStateHelpers::isValidGroup(groupA) && groupA == groupB)
			return false;
	}

	return true;
}

void PerformanceView::addExistingLinkMenuOptions(const juce::Array<int>& activeSlots, juce::PopupMenu& menu)
{
	menu.addSeparator();

	juce::PopupMenu linkMaskMenu;
	setupLinkMaskMenu(activeSlots, linkMaskMenu);
	menu.addSubMenu("Link Masks", linkMaskMenu);

	juce::PopupMenu colourMenu;
	setupLinkColourMenu(activeSlots, colourMenu);
	menu.addSubMenu("Link Colour", colourMenu);

	menu.addItem(ContextMenuID::CollectLinkedFader, "Collect Linked Fader");

	menu.addItem(CustomUnlink, "Remove Link");
}

void PerformanceView::addStereoMenuItems(const juce::Array<int>& selectedArr, juce::PopupMenu& menu) const
{
	for (int idx : selectedArr)
	{
		if (SlotStateHelpers::isXpStereo(processor.apvts.state, idx))
			return;
	}

	if (selectedArr.size() == 2)
	{
		if (!SlotStateHelpers::isStereoLinked(processor.apvts.state, selectedArr[0]) &&
			!SlotStateHelpers::isStereoLinked(processor.apvts.state, selectedArr[1])
			) {
			menu.addItem(1, "Stereo Link Pairs");
		}
	}
	else if (selectedArr.size() == 1)
	{
		if (SlotStateHelpers::isStereoLinked(processor.apvts.state, selectedArr[0]))
			menu.addItem(2, "Unlink Stereo Pair");
	}
}

void PerformanceView::addLinkMaskMenu(const juce::Array<int>& activeSlots, const juce::Array<int>& normalSlots, const juce::Array<int>& vcaSlots, juce::PopupMenu& menu) const
{
	if (normalSlots.size() == 1 && vcaSlots.size() == 1)
	{
		int normalId = normalSlots[0];
		int vcaId = vcaSlots[0];
		if (SlotStateHelpers::getGroupId(processor.apvts.state, normalId) == vcaId)
			return;
	}

	if (normalSlots.size() == 2)
	{
		int group1 = SlotStateHelpers::getGroupId(processor.apvts.state, normalSlots[0]);
		int group2 = SlotStateHelpers::getGroupId(processor.apvts.state, normalSlots[1]);
		if (SlotStateHelpers::isValidGroup(group1) && group1 == group2)
			return;
	}

	menu.addSeparator();
	juce::PopupMenu linkMaskMenu;
	setupLinkMaskMenu(activeSlots, linkMaskMenu);
	menu.addSubMenu("Link Masks", linkMaskMenu);
}

void PerformanceView::setupLinkMaskMenu(const juce::Array<int>& activeSlots, juce::PopupMenu& linkMaskMenu) const
{
	int slotIdx = activeSlots[0];
	auto& state = processor.apvts.state;

	linkMaskMenu.addItem(LinkMaskPolarityParallel, "Parallel Link (1:1)", true, !SlotStateHelpers::isLinkPolarityInverse(state, slotIdx));
	linkMaskMenu.addItem(LinkMaskPolarityInverse, "Inverse Link (Mirror)", true, SlotStateHelpers::isLinkPolarityInverse(state, slotIdx));
	linkMaskMenu.addSeparator();
	linkMaskMenu.addItem(LinkMaskVolume, "Link Volume", true, SlotStateHelpers::isLinkMaskVolume(state, slotIdx));
	linkMaskMenu.addItem(LinkMaskMute, "Link Mute", true, SlotStateHelpers::isLinkMaskMute(state, slotIdx));

	juce::Array<int> slotsToCheck = activeSlots;
	if (slotsToCheck.size() == 1)
	{
		int linkedId = getLinkedSelectionId(slotIdx);
		if (linkedId != 0)
			slotsToCheck.add(linkedId);
	}

	bool showSolo = true;
	bool showPan = true;

	for (int id : slotsToCheck)
	{
		if (isVcaSelection(id))
		{
			showSolo = false;
			showPan = false;
			break;
		}

		if (!SlotStateHelpers::isStereoMain(state, id) && !SlotStateHelpers::isXpStereo(state, id))
		{
			showPan = false;
		}
	}

	if (showSolo)
		linkMaskMenu.addItem(LinkMaskSolo, "Link Solo", true, SlotStateHelpers::isLinkMaskSolo(state, slotIdx));

	if (showPan)
		linkMaskMenu.addItem(LinkMaskPan, "Link Pan", true, SlotStateHelpers::isLinkMaskPan(state, slotIdx));
}

void PerformanceView::handleLinkMaskResult(int result, const juce::Array<int>& activeSlots)
{
	int slotA = activeSlots[0];
	int slotB = getLinkedSelectionId(slotA);

	if (slotB == 0) return;

	processor.undoManager.beginNewTransaction("Update Link Masks");

	juce::Array<int> slotsToUpdate = { slotA, slotB };
	auto& state = processor.apvts.state;

	for (int idx : slotsToUpdate)
	{
		switch (result)
		{
		case LinkMaskPolarityParallel:
			SlotStateHelpers::setLinkPolarityInverse(state, idx, false, &processor.undoManager);
			break;
		case LinkMaskPolarityInverse:
			SlotStateHelpers::setLinkPolarityInverse(state, idx, true, &processor.undoManager);
			break;
		case LinkMaskVolume:
			SlotStateHelpers::setLinkMaskVolume(state, idx, !SlotStateHelpers::isLinkMaskVolume(state, idx), &processor.undoManager);
			break;
		case LinkMaskMute:
			SlotStateHelpers::setLinkMaskMute(state, idx, !SlotStateHelpers::isLinkMaskMute(state, idx), &processor.undoManager);
			break;
		case LinkMaskSolo:
			SlotStateHelpers::setLinkMaskSolo(state, idx, !SlotStateHelpers::isLinkMaskSolo(state, idx), &processor.undoManager);
			break;
		case LinkMaskPan:
			SlotStateHelpers::setLinkMaskPan(state, idx, !SlotStateHelpers::isLinkMaskPan(state, idx), &processor.undoManager);
			break;
		default:
			break;
		}
	}

	triggerAsyncUpdate();
}

void PerformanceView::addGroupMenu(const juce::Array<int>& selectedArr, juce::PopupMenu& menu)
{
	menu.addSeparator();
	juce::PopupMenu groupMenu;
	setupGroupMenu(selectedArr, groupMenu);
	menu.addSubMenu("Grouping", groupMenu);
}

void PerformanceView::setupGroupMenu(const juce::Array<int>& selectedArr, juce::PopupMenu& groupMenu) const
{
	for (int i = 1; i <= PluginConstants::numGroups; ++i)
		groupMenu.addItem(AssignGroupBase + i, "Assign to Group " + juce::String(i));

	groupMenu.addSeparator();

	int slotIdx = selectedArr[0];
	int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotIdx);

	if (SlotStateHelpers::isValidGroup(grpId))
		groupMenu.addItem(RemoveGroup, "Remove from Group");
}

void PerformanceView::addSingleSlotGroupOptions(const juce::Array<int>& selectedArr, juce::PopupMenu& menu)
{
	int slotIdx = selectedArr[0];
	int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotIdx);
	GroupRole role = SlotStateHelpers::getGroupRole(processor.apvts.state, slotIdx);

	if (SlotStateHelpers::isValidGroup(grpId))
	{
		menu.addSeparator();
		addGroupMemberItems(role, menu);
	}
}

void PerformanceView::addGroupMemberItems(GroupRole role, juce::PopupMenu& menu)
{
	if (role == GroupRole::Member)
		menu.addItem(PromoteLeader, "Promote to Group Leader");
	else if (role == GroupRole::Leader)
		menu.addItem(DemoteMember, "Demote to Standard Member");
}

void PerformanceView::addVcaMenuItem(juce::PopupMenu& menu, int grpId) const
{
	menu.addSeparator();
	bool vcaEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, grpId);
	menu.addItem(ToggleVCA, vcaEnabled ? "Disable VCA Master" : "Enable VCA Master", true, false);
}

void PerformanceView::setupAndAddGrpColourMenu(juce::PopupMenu& menu, int grpId)
{
	menu.addSeparator();
	juce::PopupMenu colourMenu;
	setupGrpColourMenu(grpId, colourMenu);
	menu.addSubMenu("Group Colour", colourMenu);
}

void PerformanceView::setupGrpColourMenu(int grpId, juce::PopupMenu& colourMenu) const
{
	int currentColourIdx = SlotStateHelpers::getGroupColour(processor.apvts.state, grpId);

	bool isCurrentlyAuto = !processor.apvts.state.hasProperty(SlotIDs::groupColour(grpId));

	colourMenu.addItem(AssignColourBase + GroupColours::numColours, "Auto", true, isCurrentlyAuto);
	colourMenu.addSeparator();

	for (int i = 0; i < GroupColours::numColours; ++i)
	{
		bool isUsedByAnotherGroup = SlotStateHelpers::isGroupColourClaimed(processor.apvts.state, i, grpId);

		colourMenu.addItem(AssignColourBase + i, GroupColours::names[i], !isUsedByAnotherGroup, currentColourIdx == i && !isCurrentlyAuto);
	}
}

void PerformanceView::showPopupMenuIfNotEmpty(juce::PopupMenu& menu, const juce::Array<int>& selectedArr)
{
	if (menu.getNumItems() > 0) 
	{
		menu.showMenuAsync(juce::PopupMenu::Options().withParentComponent(this), [this, selectedArr](int result)
			{
				handlePopupMenuResult(result, selectedArr);
			});
	}
}

void PerformanceView::handlePopupMenuResult(int result, const juce::Array<int>& selectedArr)
{
	if (result == 0 || selectedArr.isEmpty()) return;

	if (result == ClaimSlot)
	{
		handleClaimSlot(selectedArr);
		return;
	}

	juce::Array<int> activeSlots;
	fillActiveSlots(selectedArr, activeSlots);

	if (activeSlots.isEmpty()) return;

	if (result > AssignGroupBase && result <= AssignGroupBase + GroupColours::numColours)
	{
		handleGroupAssignment(result, activeSlots);
		return;
	}

	if (result >= AssignColourBase && result <= AssignColourBase + GroupColours::numColours)
	{
		handleColourAssignment(activeSlots, result);
		return;
	}

	if (result >= LinkMaskBase && result <= LinkMaskPan) {
		handleLinkMaskResult(result, activeSlots); 
		return;
	}

	if (result >= AssignLinkColourBase && result < AssignLinkColourBase + GroupColours::numColours)
	{
		handleLinkColourAssignment(activeSlots, result);
		return;
	}

	switch (result) {
		case StereoLink:
			if (activeSlots.size() == 2) doStereoLink(activeSlots[0], activeSlots[1]);
			break;

		case StereoUnlink:
			if (activeSlots.size() == 1) doStereoUnlink(activeSlots[0]);
			break;

		case RemoveGroup:
			for (int idx : activeSlots) setSlotStandardGroup(idx, 0, GroupRole::Member);
			break;

		case PromoteLeader:
			if (activeSlots.size() == 1) promoteToGroupLeader(activeSlots[0]);
			break;

		case DemoteMember:
			if (activeSlots.size() == 1) demoteToStandardMember(activeSlots[0]);
			break;

		case ToggleVCA:
			if (!activeSlots.isEmpty())
			{
				int id = activeSlots[0];
				int grpId = (id > PluginConstants::vcaSelectionOffset) 
					? (id - PluginConstants::vcaSelectionOffset) 
					: SlotStateHelpers::getGroupId(processor.apvts.state, id);

				if (SlotStateHelpers::isValidGroup(grpId))
					toggleVcaMaster(grpId);
			}
			break;

		case ToggleSoloSafe:
			toggleSoloSafe(activeSlots);
			break;

		case ClearAllSolos:
			handleClearAllSolos();
			break;

		case CustomUnlink:
			handleCustomUnlink(activeSlots);
			break;

		case CreateCustomLink:
			handleCreateCustomLink(activeSlots);
			break;

		case CollectGroupSlots:
			handleCollectGroupSlots(selectedArr[0]);
			break;

		case ContextMenuID::CollectLinkedFader:
			handleCollectLinkedFader(selectedArr[0]);
			break;

		default:
			break;
	}
}

void PerformanceView::handleCreateCustomLink(juce::Array<int>& activeSlots)
{
	if (activeSlots.size() != 2) return;

	int slotA = activeSlots[0];
	int slotB = activeSlots[1];
	auto& state = processor.apvts.state;

	processor.undoManager.beginNewTransaction("Create Custom Link");

	SlotStateHelpers::setCustomLinkedId(state, slotA, getTrueId(slotB), &processor.undoManager);
	SlotStateHelpers::setCustomLinkedIsVca(state, slotA, isVcaSelection(slotB), &processor.undoManager);

	SlotStateHelpers::setCustomLinkedId(state, slotB, getTrueId(slotA), &processor.undoManager);
	SlotStateHelpers::setCustomLinkedIsVca(state, slotB, isVcaSelection(slotA), &processor.undoManager);

	int chosenColour = getAvailableLinkColourIndex();
	SlotStateHelpers::setLinkColourIndex(state, slotA, chosenColour, &processor.undoManager);
	SlotStateHelpers::setLinkColourIndex(state, slotB, chosenColour, &processor.undoManager);

	applyDefaultLinkMasks(slotA);
	applyDefaultLinkMasks(slotB);

	triggerAsyncUpdate();
}

void PerformanceView::handleCustomUnlink(juce::Array<int>& activeSlots)
{
	if (activeSlots.isEmpty()) return;

	int slotA = activeSlots[0];
	int slotB = getLinkedSelectionId(slotA);

	processor.undoManager.beginNewTransaction("Remove Custom Link");

	clearLinkState(slotA);

	if (slotB != 0)
	{
		clearLinkState(slotB);
	}

	triggerAsyncUpdate();
}

void PerformanceView::applyDefaultLinkMasks(int slotId)
{
	auto& state = processor.apvts.state;
	SlotStateHelpers::setLinkPolarityInverse(state, slotId, false, &processor.undoManager);
	SlotStateHelpers::setLinkMaskVolume(state, slotId, true, &processor.undoManager);
	SlotStateHelpers::setLinkMaskMute(state, slotId, true, &processor.undoManager);
	SlotStateHelpers::setLinkMaskSolo(state, slotId, true, &processor.undoManager);
	SlotStateHelpers::setLinkMaskPan(state, slotId, true, &processor.undoManager);
}

void PerformanceView::clearLinkState(int slotId)
{
	auto& state = processor.apvts.state;
	SlotStateHelpers::setCustomLinkedId(state, slotId, 0, &processor.undoManager);
	SlotStateHelpers::setCustomLinkedIsVca(state, slotId, false, &processor.undoManager);
	SlotStateHelpers::removeProp(state, SlotIDs::linkColourIndex(slotId), &processor.undoManager);
}

juce::Array<int> PerformanceView::getUsedLinkColours(int ignoreSlotA, int ignoreSlotB) const
{
	juce::Array<int> usedColours;
	auto& state = processor.apvts.state;

	auto checkAndAdd = [&](int slotId) {
		if (slotId == ignoreSlotA || slotId == ignoreSlotB) return;

		if (SlotStateHelpers::getCustomLinkedId(state, slotId) != 0)
			usedColours.addIfNotAlreadyThere(SlotStateHelpers::getLinkColourIndex(state, slotId));
		};

	for (int i = 1; i <= PluginConstants::numSlots; ++i)
		checkAndAdd(i);

	for (int i = 1; i <= PluginConstants::numVcas; ++i)
		checkAndAdd(makeSelectionId(i, true));

	return usedColours;
}

int PerformanceView::getAvailableLinkColourIndex() const
{
	juce::Array<int> usedColours = getUsedLinkColours();

	for (int i = 0; i < GroupColours::numColours; ++i)
	{
		if (!usedColours.contains(i))
			return i;
	}

	return 0;
}

void PerformanceView::setupLinkColourMenu(const juce::Array<int>& activeSlots, juce::PopupMenu& colourMenu) const
{
	int slotA = activeSlots[0];
	int slotB = getLinkedSelectionId(slotA);

	int currentColourIdx = SlotStateHelpers::getLinkColourIndex(processor.apvts.state, slotA);

	juce::Array<int> usedColours = getUsedLinkColours(slotA, slotB);

	for (int i = 0; i < GroupColours::numColours; ++i)
	{
		bool isUsedByAnotherLink = usedColours.contains(i);

		colourMenu.addItem(AssignLinkColourBase + i, GroupColours::names[i], !isUsedByAnotherLink, currentColourIdx == i);
	}
}

void PerformanceView::handleLinkColourAssignment(const juce::Array<int>& activeSlots, int result)
{
	int colourIdx = result - AssignLinkColourBase;
	int slotA = activeSlots[0];
	int slotB = getLinkedSelectionId(slotA);

	if (slotB == 0) return;

	processor.undoManager.beginNewTransaction("Set Link Colour");

	SlotStateHelpers::setLinkColourIndex(processor.apvts.state, slotA, colourIdx, &processor.undoManager);
	SlotStateHelpers::setLinkColourIndex(processor.apvts.state, slotB, colourIdx, &processor.undoManager);

	triggerAsyncUpdate();
}

void PerformanceView::handleClaimSlot(const juce::Array<int>& selectedArr)
{
	processor.undoManager.beginNewTransaction("Claim Slots");

	for (int idx : selectedArr)
	{
		if (!isSlotFullAccess(idx))
		{
			processor.globalSlotRegistry->claimSlot(idx, processor.getInstanceId());

			SlotStateHelpers::setSlotActive(processor.apvts, idx, true);
		}
	}
	selectedItems.deselectAll();
}

void PerformanceView::fillActiveSlots(const juce::Array<int>& selectedArr, juce::Array<int>& activeSlots)
{
	for (int idx : selectedArr)
	{
		if (idx > PluginConstants::vcaSelectionOffset || isSlotFullAccess(idx))
			activeSlots.add(idx);
	}
}

void PerformanceView::handleGroupAssignment(int result, const juce::Array<int>& selectedArr)
{
	int groupId = result - AssignGroupBase;
	for (int idx : selectedArr)
		setSlotStandardGroup(idx, groupId, GroupRole::Member);
}

void PerformanceView::addSoloSafeMenuItem(const juce::Array<int>& activeSlots, juce::PopupMenu& menu) const
{
	if (activeSlots.isEmpty()) return;

	bool allSafe = true;
	for (int idx : activeSlots)
	{
		if (!SlotStateHelpers::isSlotSoloSafe(processor.apvts, idx))
		{
			allSafe = false;
			break;
		}
	}

	menu.addSeparator();

	juce::String text = activeSlots.size() == 1 ? "Solo Safe" : "Solo Safe (Bulk)";
	menu.addItem(ToggleSoloSafe, text, true, allSafe);

	bool anySoloActive = false;
	for (int i = 1; i <= PluginConstants::numSlots; ++i) {
		if (SlotStateHelpers::isSlotSoloed(processor.apvts, i)) {
			anySoloActive = true;
			break;
		}
	}

	if (anySoloActive)
		menu.addItem(ClearAllSolos, "Clear All Solos");
}

void PerformanceView::handleColourAssignment(const juce::Array<int>& selectedArr, int result)
{
	if (selectedArr.isEmpty()) return;

	int id = selectedArr[0];

	int grpId = (id > PluginConstants::vcaSelectionOffset) 
		? (id - PluginConstants::vcaSelectionOffset) 
		: SlotStateHelpers::getGroupId(processor.apvts.state, id);

	if (SlotStateHelpers::isValidGroup(grpId))
	{
		processor.undoManager.beginNewTransaction("Set Group Colour");

		if (result == AssignColourBase + GroupColours::numColours)
		{
			SlotStateHelpers::clearGroupColour(processor.apvts.state, grpId, &processor.undoManager);
		}
		else
		{
			int colourIdx = result - AssignColourBase;
			SlotStateHelpers::setGroupColour(processor.apvts.state, grpId, colourIdx, &processor.undoManager);
		}
	}
}

void PerformanceView::doStereoLink(int slotA, int slotB)
{
	if (SlotStateHelpers::isStereoLinked(processor.apvts.state, slotA) ||
		SlotStateHelpers::isStereoLinked(processor.apvts.state, slotB))
	{
		selectedItems.deselectAll();
		return;
	}

	processor.undoManager.beginNewTransaction("Stereo Link");

	auto& state = processor.apvts.state;
	int mainIdx = juce::jmin(slotA, slotB);
	int subIdx = juce::jmax(slotA, slotB);

	setMainSlotProperties(state, mainIdx, subIdx);
	setSubSlotProperties(state, subIdx, mainIdx);

	selectedItems.deselectAll();
}

void PerformanceView::setMainSlotProperties(juce::ValueTree& state, int mainIdx, int subIdx)
{
	SlotStateHelpers::setStereoLinked(state, mainIdx, true, &processor.undoManager);
	SlotStateHelpers::setStereoMain(state, mainIdx, true, &processor.undoManager);
	SlotStateHelpers::setLinkedSlotId(state, mainIdx, subIdx, &processor.undoManager);
}

void PerformanceView::setSubSlotProperties(juce::ValueTree& state, int subIdx, int mainIdx)
{
	SlotStateHelpers::setStereoLinked(state, subIdx, true, &processor.undoManager);
	SlotStateHelpers::setStereoMain(state, subIdx, false, &processor.undoManager);
	SlotStateHelpers::setLinkedSlotId(state, subIdx, mainIdx, &processor.undoManager);

	SlotStateHelpers::setGroupId(state, subIdx, 0, &processor.undoManager);
	SlotStateHelpers::setGroupRole(state, subIdx, GroupRole::Member, &processor.undoManager);
}

void PerformanceView::doStereoUnlink(int slotIdx)
{
	auto& state = processor.apvts.state;
	int linkedIdx = SlotStateHelpers::getLinkedSlotId(state, slotIdx);

	processor.undoManager.beginNewTransaction("Stereo Unlink");

	SlotStateHelpers::unlinkStereoSlot(state, slotIdx, &processor.undoManager);
	if (linkedIdx != -1) 
		SlotStateHelpers::unlinkStereoSlot(state, linkedIdx, &processor.undoManager);

	selectedItems.deselectAll();
}

void PerformanceView::triggerSettling()
{
	isSettling = true;
	startTimer(200);
	triggerAsyncUpdate();
}

void PerformanceView::promoteToGroupLeader(int slotIdx)
{
	int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotIdx);
	if (grpId == 0) return;

	processor.undoManager.beginNewTransaction("Promote Group Leader");

	demoteExistingGroupLeaders(grpId);
	setSlotStandardGroup(slotIdx, grpId, GroupRole::Leader);
}

void PerformanceView::demoteExistingGroupLeaders(int grpId)
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		int otherGrpId = SlotStateHelpers::getGroupId(processor.apvts.state, i);
		GroupRole otherRole = SlotStateHelpers::getGroupRole(processor.apvts.state, i);

		if (otherGrpId == grpId && otherRole == GroupRole::Leader)
		{
			setSlotStandardGroup(i, grpId, GroupRole::Member);
		}
	}
}

void PerformanceView::setSlotStandardGroup(int slotIdx, int groupId, GroupRole role)
{
	auto& state = processor.apvts.state;
	SlotStateHelpers::setGroupId(state, slotIdx, groupId, &processor.undoManager);
	SlotStateHelpers::setGroupRole(state, slotIdx, role, &processor.undoManager);
}

void PerformanceView::demoteToStandardMember(int slotIdx)
{
	processor.undoManager.beginNewTransaction("Demote to Member");
	int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotIdx);
	setSlotStandardGroup(slotIdx, grpId, GroupRole::Member);
}

void PerformanceView::toggleVcaMaster(int grpId)
{
	processor.undoManager.beginNewTransaction("Toggle VCA Master");
	bool currentlyEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, grpId);
	SlotStateHelpers::setParamNormalized(processor.apvts, SlotIDs::vcaEnabled(grpId), currentlyEnabled ? 0.0f : 1.0f);
}

void PerformanceView::reactivateGroupMembers(int grpId)
{
	bool anyChanged = false;

	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		if (SlotStateHelpers::getGroupId(processor.apvts.state, i) == grpId)
		{
			bool isLocallyActive = SlotStateHelpers::isSlotActive(processor.apvts, i);

			if (!isLocallyActive)
			{
				processor.globalSlotRegistry->claimSlot(i, processor.getInstanceId());
				SlotStateHelpers::setSlotActive(processor.apvts, i, true);

				anyChanged = true;
			}
		}
	}

	if (anyChanged)
	{
		triggerAsyncUpdate();
	}
}

void PerformanceView::toggleSoloSafe(const juce::Array<int>& activeSlots)
{
	processor.undoManager.beginNewTransaction("Toggle Solo Safe");

	bool allSafe = true;
	for (int idx : activeSlots)
	{
		if (!SlotStateHelpers::isSlotSoloSafe(processor.apvts, idx))
		{
			allSafe = false;
			break;
		}
	}

	bool targetState = !allSafe;

	for (int idx : activeSlots)
	{
		SlotStateHelpers::setSlotSoloSafe(processor.apvts, idx, targetState);
	}
}

void PerformanceView::handleClearAllSolos()
{
	processor.undoManager.beginNewTransaction("Clear All Solos");

	LinkManager::ScopedPropagationBypass linkBypass(*processor.linkManager);

	bool anyChanged = false;

	for (int i = 1; i <= PluginConstants::numSlots; ++i) 
	{
		if (SlotStateHelpers::isSlotSoloed(processor.apvts, i)) 
		{
			SlotStateHelpers::setSlotSoloed(processor.apvts, i, false);
			anyChanged = true;
		}
	}

	if (anyChanged)
		triggerAsyncUpdate();
}

void PerformanceView::handleCollectGroupSlots(int clickedSelectionId)
{
	int targetGroupId = getTargetGroupId(clickedSelectionId);

	if (!SlotStateHelpers::isValidGroup(targetGroupId))
		return;

	juce::Array<int> groupItems;
	juce::Array<int> nonGroupItems;
	int originalClickedIndex = -1;
	int vcaSelectionId = -1;

	filterLayoutListsForGroupCollect(clickedSelectionId, originalClickedIndex, vcaSelectionId, targetGroupId, groupItems, nonGroupItems);

	if (groupItems.size() <= 1 || originalClickedIndex == -1)
		return;

	if (vcaSelectionId != -1 && groupItems.getLast() != vcaSelectionId)
	{
		groupItems.removeAllInstancesOf(vcaSelectionId);
		groupItems.add(vcaSelectionId);
	}

	int targetStartIndex = calcTargetIndexForGroupCollect(clickedSelectionId, originalClickedIndex, nonGroupItems, groupItems);

	juce::Array<int> newOrder = nonGroupItems;
	newOrder.insertArray(targetStartIndex, groupItems.getRawDataPointer(), groupItems.size());

	applyNewSlotOrder(newOrder, "Collect Group Slots");
	triggerAsyncUpdate();
}

int PerformanceView::getTargetGroupId(int clickedSelectionId)
{
	int targetGroupId;
	if (isVcaSelection(clickedSelectionId))
		targetGroupId = getTrueId(clickedSelectionId);
	else
		targetGroupId = SlotStateHelpers::getGroupId(processor.apvts.state, clickedSelectionId);
	return targetGroupId;
}

void PerformanceView::filterLayoutListsForGroupCollect(int clickedSelectionId, int& originalClickedIndex, int& vcaSelectionId, int targetGroupId, juce::Array<int>& groupItems, juce::Array<int>& nonGroupItems)
{
	for (int i = 0; i < visualSlotOrder.size(); ++i)
	{
		int id = visualSlotOrder[i];

		if (id == clickedSelectionId)
			originalClickedIndex = i;

		bool isGroupMember = false;
		if (isVcaSelection(id))
		{
			if (getTrueId(id) == targetGroupId) {
				isGroupMember = true;
				vcaSelectionId = id;
			}
		}
		else
			isGroupMember = (SlotStateHelpers::getGroupId(processor.apvts.state, id) == targetGroupId);

		if (isGroupMember)
			groupItems.add(id);
		else
			nonGroupItems.add(id);
	}
}

int PerformanceView::calcTargetIndexForGroupCollect(int clickedSelectionId, int originalClickedIndex, juce::Array<int>& nonGroupItems, juce::Array<int>& groupItems) const
{
	int relativeIndexInGroup = groupItems.indexOf(clickedSelectionId);

	int targetStartIndex = originalClickedIndex - relativeIndexInGroup;
	targetStartIndex = juce::jlimit(0, nonGroupItems.size(), targetStartIndex);

	return targetStartIndex;
}

void PerformanceView::handleCollectLinkedFader(int clickedSelectionId)
{
	int linkedId = getLinkedSelectionId(clickedSelectionId);

	if (linkedId == 0)
		return;

	juce::Array<int> newOrder = visualSlotOrder;

	newOrder.removeAllInstancesOf(linkedId);

	int targetIndex = newOrder.indexOf(clickedSelectionId);

	if (targetIndex != -1)
	{
		newOrder.insert(targetIndex + 1, linkedId);

		applyNewSlotOrder(newOrder, "Collect Linked Fader");
		triggerAsyncUpdate();
	}
}

void PerformanceView::paint(juce::Graphics& g)
{
	g.setColour(MyColours::cbBlue);
	g.fillRect(headerArea);
	g.fillRect(footerArea);
}

void PerformanceView::paintOverChildren(juce::Graphics& g)
{
	paintPinnedStoreBtns(g);
	paintDragDropInsertionMarker(g);
}

void PerformanceView::paintPinnedStoreBtns(juce::Graphics& g)
{
	int activeStoreId = SlotStateHelpers::getActiveStoreId(processor.apvts);

	for (auto* btn : pinnedStoreButtons)
	{
		if (static_cast<int>(btn->getProperties()[PresetTags::StoreIdProp]) == activeStoreId)
		{
			auto b = btn->getBounds();
			g.setColour(hasUnsavedChanges ? juce::Colours::red : juce::Colours::limegreen);
			g.fillEllipse((float)b.getRight() - 8.0f, (float)b.getY() + 2.0f, 6.0f, 6.0f);
		}
	}
}

void PerformanceView::paintDragDropInsertionMarker(juce::Graphics& g)
{
	if (currentDragInsertIndex >= 0)
	{
		int top = 0;
		int bottom = 0;
		int lineX = getDragLineX(top, bottom);

		if (lineX >= 0)
		{
			g.setColour(juce::Colours::white.withAlpha(0.9f));
			g.fillRect((float)lineX - 1.0f, (float)top, 2.0f, (float)(bottom - top));

			juce::Path p;
			p.addTriangle((float)lineX - 6.0f, (float)top,
				(float)lineX + 6.0f, (float)top,
				(float)lineX, (float)top + 7.0f);

			p.addTriangle((float)lineX - 6.0f, (float)bottom,
				(float)lineX + 6.0f, (float)bottom,
				(float)lineX, (float)bottom - 7.0f);
			g.fillPath(p);
		}
	}
}

void PerformanceView::resized()
{
	if (getWidth() <= 0 || getHeight() <= 0)
		return;

	setupAndFillHeader();
	setupAndFillArea();

	juce::String currentSignature = getLayoutSignature();
	bool structureChanged = (currentSignature != lastLayoutSignature);
	bool widthChanged = (getWidth() != lastWindowWidth);

	int expectedPreservedWidth = getCurrentPreservedWidth();

	bool isAutoResize = std::abs(getWidth() - expectedPreservedWidth) <= 2;

	if ((widthChanged && !structureChanged && !isAutoResize) || currentBaselineWidth < 10.0f)
	{
		float baselineWidth = currentBaselineWidth;
		setBaselineWidth(baselineWidth);
	}

	performanceLF.updateGlobalTypography(currentBaselineWidth);

	regularSlotsOnResized(currentBaselineWidth);
	vcaSlotsOnResized(currentBaselineWidth);

	lastWindowWidth = getWidth();
	lastLayoutSignature = currentSignature;
}

void PerformanceView::setBaselineWidth(float& baselineWidth)
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		auto info = getSlotDisplayInfo(i);
		if (info.shouldProcess && info.isVisible)
		{
			baselineWidth = getSlotItem(i)->getWidth() / getSlotWidthMultiplier(info.isStereoMain);
			currentBaselineWidth = baselineWidth;
			return;
		}
	}

	for (int g = 1; g <= PluginConstants::numVcas; ++g)
	{
		if (SlotStateHelpers::isVcaEnabled(processor.apvts, g))
		{
			baselineWidth = getVcaItem(g)->getWidth() / getVcaWidthMultiplier();
			currentBaselineWidth = baselineWidth;
			return;
		}
	}

	baselineWidth = currentBaselineWidth;
}

int PerformanceView::getCurrentPreservedWidth()
{
	float preservedWidth = 0.0f;
	int activeCount = 0;

	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		auto info = getSlotDisplayInfo(i);
		if (info.shouldProcess && info.isVisible)
		{
			preservedWidth += currentBaselineWidth * getSlotWidthMultiplier(info.isStereoMain);
			activeCount++;
		}
	}

	for (int g = 1; g <= PluginConstants::numVcas; ++g)
	{
		if (SlotStateHelpers::isVcaEnabled(processor.apvts, g))
		{
			preservedWidth += currentBaselineWidth * getVcaWidthMultiplier();
			activeCount++;
		}
	}

	if (activeCount == 0)
		return WindowSizeValues::absolutePerfMinWidth;

	return juce::jlimit(getMinWidth(), WindowSizeValues::maxWidth, (int)std::round(preservedWidth));
}

float PerformanceView::getSlotWidthMultiplier(bool isStereoMain) const
{
	return isStereoMain
		? (SlotSizeValues::stereoSlotTargetWidth / SlotSizeValues::monoSlotTargetWidth)
		: 1.0f;
}

float PerformanceView::getVcaWidthMultiplier() const
{
	return SlotSizeValues::vcaSlotTargetWidth / SlotSizeValues::monoSlotTargetWidth;
}

void PerformanceView::regularSlotsOnResized(float baselineWidth)
{
	for (auto* item : slots)
	{
		if (item->isVisible())
		{
			item->setTargetSlotWidth(baselineWidth);
			item->updateTypography();
		}
	}
}

void PerformanceView::vcaSlotsOnResized(float baselineWidth)
{
	for (auto* vcaItem : vcaSlots)
	{
		if (vcaItem->isVisible())
		{
			vcaItem->setTargetSlotWidth(baselineWidth);
			vcaItem->updateTypography();
		}
	}
}

void PerformanceView::setupAndFillHeader()
{
	auto area = getLocalBounds();
	int slotNumberBlueHeight = (int)(area.getHeight() * 0.045f);
	headerArea = area.removeFromTop(topButtonStripHeight + slotNumberBlueHeight);

	auto buttonStrip = headerArea.withHeight(topButtonStripHeight).reduced(4);

	juce::FlexBox fb;
	fb.flexDirection = juce::FlexBox::Direction::row;
	fb.flexWrap = juce::FlexBox::Wrap::noWrap;
	fb.alignItems = juce::FlexBox::AlignItems::stretch;

	fb.items.add(juce::FlexItem(setupButton)
		.withFlex(1.0f).withMinWidth(45.0f).withMaxWidth(80.0f)
		.withMargin(juce::FlexItem::Margin(0, 5, 0, 0)));

	fb.items.add(juce::FlexItem(activeStoreLabel)
		.withFlex(1.5f).withMinWidth(60.0f).withMaxWidth(120.0f)
		.withMargin(juce::FlexItem::Margin(0, 5, 0, 0)));

	fb.items.add(juce::FlexItem(editLayoutButton)
		.withFlex(1.5f).withMinWidth(70.0f).withMaxWidth(100.0f));

	fb.items.add(juce::FlexItem().withFlex(1.0f));

	fb.items.add(juce::FlexItem(xPatchImg)
		.withFlex(1.2f).withMinWidth(40.0f).withMaxWidth(70.0f));

	fb.items.add(juce::FlexItem().withFlex(1.8f));

	fb.items.add(juce::FlexItem(presetsButton)
		.withFlex(1.0f).withMinWidth(50.0f).withMaxWidth(80.0f));

	fb.performLayout(buttonStrip);

	float labelFontSize = juce::jlimit(11.0f, 15.0f, activeStoreLabel.getWidth() * 0.18f);
	activeStoreLabel.setFont(juce::Font(labelFontSize, juce::Font::bold));
}

void PerformanceView::setupAndFillArea()
{
	auto area = getLocalBounds();

	area.removeFromTop(topButtonStripHeight);

	setupAndFillFooter(area);
	juce::FlexBox flexBox = configFlexBox();
	checkAndAddActiveSlots(flexBox);
	flexBox.performLayout(area);
}

void PerformanceView::setupAndFillFooter(juce::Rectangle<int>& area)
{
	footerArea = area.removeFromBottom(40);
	auto areaToUse = footerArea;

	storesButton.setBounds(areaToUse.removeFromLeft(80).reduced(5));

	auto logoArea = areaToUse.removeFromRight(100);
	cbLogo.setBounds(logoArea.withSizeKeepingCentre(50, logoArea.getHeight()).reduced(5));

	updatePinnedButtons();

	setupPinnedStoresFlexBox(areaToUse);
}

void PerformanceView::setupPinnedStoresFlexBox(const juce::Rectangle<int>& areaToUse)
{
	juce::FlexBox storeBox;
	storeBox.flexDirection = juce::FlexBox::Direction::row;
	storeBox.justifyContent = juce::FlexBox::JustifyContent::center;
	storeBox.alignItems = juce::FlexBox::AlignItems::center;

	addPinnedStoreButtons(storeBox);

	storeBox.performLayout(areaToUse);
}

void PerformanceView::addPinnedStoreButtons(juce::FlexBox& storeBox)
{
	for (auto* btn : pinnedStoreButtons)
	{
		storeBox.items.add(juce::FlexItem(*btn)
			.withWidth(50)
			.withHeight(34)
			.withMargin(juce::FlexItem::Margin(0, 3, 0, 3)));
	}
}

juce::FlexBox PerformanceView::configFlexBox()
{
	juce::FlexBox flexBox;
	flexBox.flexDirection = juce::FlexBox::Direction::row;
	flexBox.flexWrap = juce::FlexBox::Wrap::noWrap;
	flexBox.alignContent = juce::FlexBox::AlignContent::stretch;
	flexBox.justifyContent = juce::FlexBox::JustifyContent::center;
	return flexBox;
}

void PerformanceView::checkAndAddActiveSlots(juce::FlexBox& flexBox)
{
	for (int selectionId : visualSlotOrder)
	{
		if (isVcaSelection(selectionId))
		{
			plotSingleVca(flexBox, getTrueId(selectionId));
		}
		else
		{
			plotSingleRegularSlot(flexBox, selectionId);
		}
	}
}

void PerformanceView::plotSingleRegularSlot(juce::FlexBox& flexBox, int slotId)
{
	auto info = getSlotDisplayInfo(slotId);
	auto* slot = getSlotItem(slotId);

	if (info.mode == SlotMode::Disabled || !info.shouldProcess)
	{
		slot->setVisible(false);
		return;
	}

	slot->setMode(info.mode);
	slot->setVisible(info.isVisible);

	if (info.isVisible)
	{
		addSlotIfActive(true, flexBox, slot, info.isStereoMain);
	}
}

void PerformanceView::plotSingleVca(juce::FlexBox& flexBox, int vcaId)
{
	bool vcaEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, vcaId);
	auto* vca = getVcaItem(vcaId);

	if (vcaEnabled)
	{
		vca->setVisible(true);
		flexBox.items.add(juce::FlexItem(*vca)
			.withMaxWidth(SlotSizeValues::vcaSlotMaxWidth)
			.withFlex(SlotSizeValues::vcaSlotFlexGrowFactor));
	}
	else
	{
		vca->setVisible(false);
	}
}

void PerformanceView::hideSlotIfVcaCollapsed(int grpId, bool& shouldShow) const
{
	if (grpId >= 1 && grpId <= PluginConstants::numGroups)
	{
		bool vcaEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, grpId);
		bool isExpanded = SlotStateHelpers::isVcaExpanded(processor.apvts, grpId);

		if (vcaEnabled && !isExpanded)
		{
			shouldShow = false;
		}
	}
}

void PerformanceView::addSlotIfActive(bool isActive, juce::FlexBox& flexBox, PerformanceSlotItem* slot, bool isMainStereo)
{
	if (isActive) {
		float flexGrow = isMainStereo ? SlotSizeValues::stereoSlotFlexGrowFactor : SlotSizeValues::monoSlotFlexGrowFactor;
		float maxWidth = isMainStereo ? SlotSizeValues::stereoSlotMaxWidth : SlotSizeValues::monoSlotMaxWidth;

		flexBox.items.add(juce::FlexItem(*slot)
			.withMaxWidth(maxWidth)
			.withFlex(flexGrow));
	}
}

juce::String PerformanceView::getLayoutSignature()
{
	juce::String sig;

	for (int selectionId : visualSlotOrder)
	{
		if (isVcaSelection(selectionId))
		{
			int g = getTrueId(selectionId);
			if (SlotStateHelpers::isVcaEnabled(processor.apvts, g))
				sig += "V" + juce::String(g) + "_";
		}
		else
		{
			auto info = getSlotDisplayInfo(selectionId);
			if (info.shouldProcess && info.isVisible)
			{
				sig += info.isStereoMain ? "S" : "M";
				sig += juce::String(selectionId) + "_";
			}
		}
	}

	return sig;
}

void PerformanceView::syncSlotOrderFromState()
{
	visualSlotOrder = SlotStateHelpers::getVisualSlotOrder(processor.apvts.state);
}

int PerformanceView::getIdealWidth()
{
	int targetWidth = 0;
	int activeCount = 0;

	calculateRegularSlotTargetWidth(targetWidth, activeCount);
	calculateVcaTargetWidth(targetWidth, activeCount);

	if (activeCount == 0)
		return WindowSizeValues::absolutePerfMinWidth;

	return juce::jlimit(
		WindowSizeValues::absolutePerfMinWidth,
		WindowSizeValues::maxWidth,
		targetWidth
	);
}

void PerformanceView::calculateRegularSlotTargetWidth(int& targetWidth, int& activeCount)
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i)
	{
		auto info = getSlotDisplayInfo(i);

		if (info.shouldProcess && info.isVisible)
		{
			targetWidth += info.isStereoMain ? SlotSizeValues::stereoSlotTargetWidth : SlotSizeValues::monoSlotTargetWidth;
			activeCount++;
		}
	}
}

void PerformanceView::calculateVcaTargetWidth(int& targetWidth, int& activeCount) const
{
	for (int g = 1; g <= PluginConstants::numVcas; ++g)
	{
		bool vcaEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, g);

		if (vcaEnabled)
		{
			targetWidth += SlotSizeValues::vcaSlotTargetWidth;
			activeCount++;
		}
	}
}

int PerformanceView::getMinWidth()
{
	int minWidth = 0;
	int activeCount = 0;

	calcRegularSlotMinWidth(minWidth, activeCount);
	calcVcaMinWidth(minWidth, activeCount);

	if (activeCount == 0)
		return WindowSizeValues::absolutePerfMinWidth;

	return juce::jmax(WindowSizeValues::absolutePerfMinWidth, minWidth);
}

void PerformanceView::calcRegularSlotMinWidth(int& minWidth, int& activeCount)
{
	for (int i = 1; i <= PluginConstants::numSlots; ++i) {
		auto info = getSlotDisplayInfo(i);

		if (info.shouldProcess && info.isVisible)
		{
			minWidth += info.isStereoMain ? SlotSizeValues::stereoSlotMinWidth : SlotSizeValues::monoSlotMinWidth;
			activeCount++;
		}
	}
}

void PerformanceView::calcVcaMinWidth(int& minWidth, int& activeCount) const
{
	for (int g = 1; g <= PluginConstants::numVcas; ++g)
	{
		bool vcaEnabled = SlotStateHelpers::isVcaEnabled(processor.apvts, g);
		if (vcaEnabled)
		{
			minWidth += SlotSizeValues::vcaSlotMinWidth;
			activeCount++;
		}
	}
}

PerformanceView::SlotDisplayInfo PerformanceView::getSlotDisplayInfo(int slotId)
{
	SlotDisplayInfo info;

	bool isLocallyActive = SlotStateHelpers::isSlotActive(processor.apvts, slotId);
	info.mode = processor.globalSlotRegistry->getSlotMode(slotId, processor.getInstanceId(), isLocallyActive);

	if (info.mode == SlotMode::Disabled)
		return info;

	bool isLinked = SlotStateHelpers::isStereoLinked(processor.apvts.state, slotId);
	info.isStereoMain = SlotStateHelpers::isStereoMain(processor.apvts.state, slotId);

	if (isLinked && !info.isStereoMain)
	{
		int linkedIdx = SlotStateHelpers::getLinkedSlotId(processor.apvts.state, slotId);
		if (linkedIdx != -1 && !SlotStateHelpers::isSlotActive(processor.apvts, linkedIdx))
		{
			// Orphaned sub-slot, treat it as a standard mono slot
		}
		else
		{
			return info;
		}
	}

	info.shouldProcess = true;

	int grpId = SlotStateHelpers::getGroupId(processor.apvts.state, slotId);
	info.isVisible = true;
	hideSlotIfVcaCollapsed(grpId, info.isVisible);

	return info;
}

bool PerformanceView::isSlotFullAccess(int slotIdx)
{
	bool isLocallyActive = SlotStateHelpers::isSlotActive(processor.apvts, slotIdx);
	return processor.globalSlotRegistry
		->getSlotMode(slotIdx, processor.getInstanceId(), isLocallyActive) == SlotMode::FullAccess;
}

void PerformanceView::updatePinnedButtons()
{
	pinnedStoreButtons.clear();

	auto pinnedIndices = processor.presetManager->getPinnedStores();

	for (int idx : pinnedIndices)
	{
		createAndAddPinnedButton(idx);
	}
}

void PerformanceView::createAndAddPinnedButton(int storeIdx)
{
	juce::String storeName = processor.presetManager->getStoreName(storeIdx);
	juce::String buttonText = juce::String(storeIdx) + "\n" + storeName;

	PinnedStoreButton* btn = new PinnedStoreButton(buttonText);
	pinnedStoreButtons.add(btn);

	btn->getProperties().set(PresetTags::StoreIdProp, storeIdx);
	addAndMakeVisible(btn);

	btn->onClick = [this, storeIdx]()
		{
			requestStoreRecall(storeIdx);
		};

	btn->onRightClick = [this, storeIdx](juce::Button* b)
		{
			showPinnedStoreMenu(storeIdx, b);
		};
}

void PerformanceView::handleSelectAll()
{
	selectedItems.deselectAll();

	for (int selectionId : visualSlotOrder) {
		if (isVcaSelection(selectionId)) 
		{
			if (SlotStateHelpers::isVcaEnabled(processor.apvts, getTrueId(selectionId))) 
			{
				selectedItems.addToSelection(selectionId);
			}
		}
		else 
		{
			auto info = getSlotDisplayInfo(selectionId);
			if (info.shouldProcess && info.isVisible) {
				selectedItems.addToSelection(selectionId);
			}
		}
	}
}

void PerformanceView::handleGroupSelected()
{
	juce::Array<int> activeSlots;
	fillActiveSlots(selectedItems.getItemArray(), activeSlots);

	if (activeSlots.isEmpty()) 
		return;

	int currentGroup = SlotStateHelpers::getGroupId(processor.apvts.state, activeSlots[0]);
	int nextGroup = (currentGroup % PluginConstants::numGroups) + 1;

	processor.undoManager.beginNewTransaction("Group Selected Faders");

	for (int idx : activeSlots)
	{
		setSlotStandardGroup(idx, nextGroup, GroupRole::Member);
	}
}

void PerformanceView::handleRemoveFromGroup()
{
	juce::Array<int> activeSlots;
	fillActiveSlots(selectedItems.getItemArray(), activeSlots);

	if (activeSlots.isEmpty()) return;

	processor.undoManager.beginNewTransaction("Remove Faders from Group");

	for (int idx : activeSlots)
	{
		setSlotStandardGroup(idx, 0, GroupRole::Member);
	}
}

void PerformanceView::handleUndo()
{
	processor.undoManager.undo();
}

void PerformanceView::handleRedo()
{
	processor.undoManager.redo();
}

void PerformanceView::handleSaveActiveStore()
{
	int index = SlotStateHelpers::getActiveStoreId(processor.apvts);
	if (index != PresetConstants::noStore)
	{
		processor.presetManager->saveStore(index, processor.apvts.copyState());
		hasUnsavedChanges = false;
		triggerSettling();
		updateActiveStoreLabel(index);
	}
}

bool PerformanceView::isVcaSelection(int selectionId) const 
{
	return selectionId > PluginConstants::vcaSelectionOffset;
}

int PerformanceView::getTrueId(int selectionId) const 
{
	return isVcaSelection(selectionId) ? selectionId - PluginConstants::vcaSelectionOffset : selectionId;
}

int PerformanceView::makeSelectionId(int trueId, bool isVca) const 
{
	return isVca ? trueId + PluginConstants::vcaSelectionOffset : trueId;
}

int PerformanceView::getLinkedSelectionId(int selectionId) const 
{
	int targetTrueId = SlotStateHelpers::getCustomLinkedId(processor.apvts.state, selectionId);
	if (targetTrueId == 0) return 0;

	bool targetIsVca = SlotStateHelpers::getCustomLinkedIsVca(processor.apvts.state, selectionId);
	return makeSelectionId(targetTrueId, targetIsVca);
}

bool PerformanceView::isInterestedInDragSource(const SourceDetails& dragSourceDetails)
{
	return isSlotDragPayload(dragSourceDetails.description.toString());
}

void PerformanceView::itemDropped(const SourceDetails& dragSourceDetails)
{
	juce::String payload = dragSourceDetails.description.toString();
	if (!isSlotDragPayload(payload))
		return;

	int draggedSelectionId = extractIdFromPayload(payload);
	int targetIndex = getInsertIndexFromPosition(dragSourceDetails.localPosition.x);
	currentDragInsertIndex = -1;
	repaint();

	juce::Array<int> itemsToMove = findItemsToMove(draggedSelectionId);
	int numItemsBeforeTarget = calcMovingItemsBeforeTarget(itemsToMove, targetIndex);

	buildAndSetNewSlotOrder(itemsToMove, targetIndex, numItemsBeforeTarget);
	triggerAsyncUpdate();
}

juce::Array<int> PerformanceView::findItemsToMove(int& draggedSelectionId)
{
	juce::Array<int> itemsToMove;
	if (selectedItems.isSelected(draggedSelectionId))
	{
		for (int id : visualSlotOrder)
		{
			if (selectedItems.isSelected(id))
				itemsToMove.add(id);
		}
	}
	else
	{
		itemsToMove.add(draggedSelectionId);
	}
	return itemsToMove;
}

int PerformanceView::calcMovingItemsBeforeTarget(juce::Array<int>& itemsToMove, int targetIndex)
{
	int counter = 0;
	for (int i = 0; i < targetIndex; ++i)
	{
		if (itemsToMove.contains(visualSlotOrder[i]))
		{
			counter++;
		}
	}
	return counter;
}

void PerformanceView::buildAndSetNewSlotOrder(juce::Array<int>& itemsToMove, int targetIndex, int numItemsBeforeTarget)
{
	juce::Array<int> newOrder = visualSlotOrder;
	for (int id : itemsToMove)
	{
		newOrder.removeAllInstancesOf(id);
	}

	int adjustedTargetIndex = targetIndex - numItemsBeforeTarget;
	for (int i = 0; i < itemsToMove.size(); ++i)
	{
		newOrder.insert(adjustedTargetIndex + i, itemsToMove[i]);
	}

	applyNewSlotOrder(newOrder, "Reorder Slots");
}

void PerformanceView::applyNewSlotOrder(const juce::Array<int>& newOrder, const juce::String& transactionName)
{
	processor.undoManager.beginNewTransaction(transactionName);
	visualSlotOrder = newOrder;
	SlotStateHelpers::setVisualSlotOrder(processor.apvts.state, visualSlotOrder, &processor.undoManager);
}

int PerformanceView::getInsertIndexFromPosition(int dropX) const
{
	for (int i = 0; i < visualSlotOrder.size(); ++i)
	{
		int currentId = visualSlotOrder[i];
		BaseSlotItem* slot = isVcaSelection(currentId) ?
			(BaseSlotItem*)getVcaItem(getTrueId(currentId)) :
			(BaseSlotItem*)getSlotItem(currentId);

		if (slot != nullptr && slot->isVisible())
		{
			if (dropX < slot->getBounds().getCentreX())
				return i;
		}
	}
	return visualSlotOrder.size();
}

int PerformanceView::getDragLineX(int& top, int& bottom) const
{
	// Find the left edge of the slot at the target index
	for (int i = currentDragInsertIndex; i < visualSlotOrder.size(); ++i)
	{
		int currentId = visualSlotOrder[i];
		BaseSlotItem* slot = isVcaSelection(currentId)
			? (BaseSlotItem*)getVcaItem(getTrueId(currentId))
			: (BaseSlotItem*)getSlotItem(currentId);

		if (slot != nullptr && slot->isVisible())
		{
			top = slot->getY();
			bottom = slot->getBottom();
			return slot->getX();
		}
	}

	// If appending to the end, find the right edge of the last visible slot
	for (int i = currentDragInsertIndex - 1; i >= 0; --i)
	{
		int currentId = visualSlotOrder[i];
		BaseSlotItem* slot = isVcaSelection(currentId) ?
			(BaseSlotItem*)getVcaItem(getTrueId(currentId)) :
			(BaseSlotItem*)getSlotItem(currentId);

		if (slot != nullptr && slot->isVisible())
		{
			top = slot->getY();
			bottom = slot->getBottom();
			return slot->getRight();
		}
	}

	return -1;
}

void PerformanceView::itemDragEnter(const SourceDetails& dragSourceDetails)
{
	if (isInterestedInDragSource(dragSourceDetails))
	{
		currentDragInsertIndex = getInsertIndexFromPosition(dragSourceDetails.localPosition.x);
		repaint();
	}
}

void PerformanceView::itemDragMove(const SourceDetails& dragSourceDetails)
{
	if (isInterestedInDragSource(dragSourceDetails))
	{
		int newIndex = getInsertIndexFromPosition(dragSourceDetails.localPosition.x);
		if (currentDragInsertIndex != newIndex)
		{
			currentDragInsertIndex = newIndex;
			repaint();
		}
	}
}

void PerformanceView::itemDragExit(const SourceDetails& dragSourceDetails)
{
	currentDragInsertIndex = -1;
	repaint();
}